def limites(PairingDistance, min_lim_p = "[HologicTagProvider_Brev]Hologic/CR/Lim_Lower_PairDist", max_lim_p = "[HologicTagProvider_Brev]Hologic/CR/Lim_Upper_PairDist"):
	num_elementos = len(PairingDistance)
	
	min_lim = tag.read(min_lim_p)
	max_lim = tag.read(max_lim_p)
	
	exceden_Max = 0
	exceden_Min = 0
	
	for i in PairingDistance:
		if i > max_lim:
			exceden_Max+=1
			
		elif i < min_lim:
			exceden_Min+=1
			
	
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/Piezas/NoCumple_max", exceden_Max)
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/Piezas/NoCumple_min", exceden_Min)
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/Piezas/total", num_elementos)
	
	p_be = num_elementos-exceden_Min-exceden_Max #Piezas en buen estado
	
	return exceden_Min, exceden_Max, p_be, num_elementos


def crear_estadisticas(ds, decimales=4):
	
	if len(ds)!=0:
		PairingDistance = [float(i["PairingDistance"]) for i in ds]
		
		
		exceden_Min, exceden_Max, p_be, num_elementos = limites(PairingDistance)
		
		PairingDistance_Estad = {
		    "Cantidad_registros"	: num_elementos,
		    "min"					: min(PairingDistance),
		    "max"					: max(PairingDistance),
		    "Promedio"				: system.math.mean(PairingDistance),
		    "Desviacion_STD"		: system.math.standardDeviation(PairingDistance),
		    "Mediana"				: system.math.median(PairingDistance),
		    "Excedieron_minimo"		: exceden_Min,
		    "Excedieron_maximo"		: exceden_Max,
		    "Piezas_buenas"			: p_be,
		    "Piezas_buenas_porc"	: (float(p_be)/float(num_elementos))*100.0,
		    "Kutosis"				: system.math.kurtosis(PairingDistance),
		    "quart_1"				: system.math.percentile(PairingDistance, 25),
		    "quart_2"				: system.math.percentile(PairingDistance, 50),
		    "quart_3"				: system.math.percentile(PairingDistance, 75)
		}
		
		for k in PairingDistance_Estad.keys(): #Redondear cantidad de decimales
			PairingDistance_Estad[k] = round(PairingDistance_Estad[k], decimales)
	else:
		PairingDistance_Estad = {
		    "Cantidad_registros"    : 0,
		    "min"                   : 0,
		    "max"                   : 0,
		    "Promedio"              : 0,
		    "Desviacion_STD"        : 0,
		    "Varianza"              : 0,
		    "Mediana"               : 0,
		    "Excedieron_minimo"     : 0,
		    "Excedieron_maximo"     : 0,
		    "Piezas_buenas"         : 0,
		    "Piezas_buenas_porc"    : 0,
		    "Kurtosis"				: 0,
		    "quart_1"				: 0,
		    "quart_2"				: 0,
		    "quart_3"				: 0
		}
		
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/Estadisticas_PD", PairingDistance_Estad)
	
	#DS de estadisticas
	headers = ["Parametro", "Valor"]
	data	= []
	for i in PairingDistance_Estad.items():
		data.append(i)
	ds_estad = system.dataset.toDataSet(headers, data)
	system.tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/Estadisticas_PD_DS", ds_estad)

def reporteADefault():
	hoy  = system.date.now()
	ayer =	system.date.addDays(hoy, -1)
	
	#Reporte:
	q 		= system.db.runNamedQuery(path = "Transacciones_Brevera_Table", parameters = {"start": ayer,"end": hoy})
	q_DS 	= system.dataset.toDataSet(q)
	arr = []
	
	for row in q: 
		dic = {}
		for k in q_DS.getColumnNames():
			dic[k] = row[k]
		arr.append(dic)
			
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/Reporte_DS", q_DS)
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/Reporte", arr)
	crear_estadisticas(arr)
	limites(arr)
	
	#Fechas:
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/StartDate"	, ayer)
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/EndDate"		, hoy)
	
	#Lotes:
	all_lots = tag.read("[HologicTagProvider_Brev]Hologic/CR/FilterData/LotNumber_List")
	tag.write("[HologicTagProvider_Brev]Hologic/CR/Reporte/LotList", all_lots)
	
	#Rangos Pairign distance:
	
	root="[HologicTagProvider_Brev]Hologic/CR/Reporte/Piezas/"
	
	tag.read(root+"Piezas_cumplen")
	tag.read(root+"NoCumple_max")
	tag.read(root+"NoCumple_min")