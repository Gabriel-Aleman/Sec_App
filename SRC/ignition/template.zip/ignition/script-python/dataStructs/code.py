def arrToDrop(LotNumberList, duplicateLabel 	= True):
	drop_list 		= []
	for i in range(len(LotNumberList)):
		dic={}
		dic["label"]	= LotNumberList[i]
		dic["value"]	= LotNumberList[i] if duplicateLabel else i
		drop_list.append(dic)
	return drop_list

def arrIntersec(arr1, arr2):		#Intersección de 2 listas
	if len(arr1)>=len(arr2):
		mainArr = arr2
		secArr	= arr1
	else:
		mainArr =arr1
		secArr	= arr2
		
	inter=[]
	for element in mainArr:
		if element in secArr:
			inter.append(element)
	return inter

def filterArr(mainArr, contArr):	#Remover un subconjunto de un conjunto principal.
	filt_arr = [] #Crear una copia
	for element in mainArr:
		if element not in contArr:
			print(element)
			filt_arr.append(element)
	return filt_arr

def DS_to_pyDSFromPath(func):
	def wrap(path, startDate=None, endDate=None):
		DS= func(path, startDate, endDate)
		py_DS	= system.dataset.toPyDataSet(DS)
		return py_DS
	return wrap
	
@DS_to_pyDSFromPath
def tagQuery(path, startDate, endDate):
	query=system.tag.queryTagHistory(startDate=startDate, endDate=endDate,paths=[path])
	return query


def multiplicarElementosDeUnaLista(lista, constante):
	for i in range(len(lista)):
		lista[i]=lista[i]*constante
	return lista
	
def dividirElementosDeUnaLista(lista, constante):
	for i in range(len(lista)):
		lista[i]=lista[i]/constante
	return lista

def sumarElementosDeUnaLista(lista, constante):
	for i in range(len(lista)):
		lista[i]=lista[i]+constante
	return lista
	
def listasAnumeros(*listas):
	listas0 = []
	for l in listas:
		try:
			l = [float(i) for i in l]
		except:
			return 0
		listas0.append(l)
		
	if len(listas)==1:
		return listas0[0]
	else:
		return listas0
		
	
def multiplicar2Arreglos(list1, list2):
	list1, list2 = listasAnumeros(list1, list2)
	
	listaProducto=[]
	for i in range(len(list1)):
		multiplicacion=list1[i]*list2[i]
		listaProducto.append(multiplicacion)
	return listaProducto
	


def dividir2Arreglos(list1, list2):
	list1, list2 = listasAnumeros(list1, list2)
	
	listaProducto=[]
	for i in range(len(list1)):
		if list2[i]==0:
			listaProducto.append(0.0)
		else:
			division=list1[i]/list2[i]
			listaProducto.append(division)
	return listaProducto