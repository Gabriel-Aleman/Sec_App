def findDictSize(doc):
	try:
		k=doc.keys()
	except:
		return 0
	else:
		doc=doc[k[0]]
		return findDictSize(doc)+1
	
def doc2Dic(doc):
	docProf=findDictSize(doc)
	doc=dict(doc)
	if docProf==1:
		return doc
	else:
		for key in doc.keys():
			doc[key]=doc2Dic(doc[key])
		return doc

def doc_2Dic_fromPath(path): #Documento a diccionario
	doc=system.tag.read(path).value
	return doc2Dic(doc)