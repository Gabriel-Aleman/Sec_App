import random
Buff_Current 	= "[HologicTagProvider_Brev]Hologic/Buff_Current"
Buff_Prev 		= "[HologicTagProvider_Brev]Hologic/Buff_Prev"


hoy 	= system.date.now()
site 	= "Hologic CR"

def returnRandomResult():
	Results={
		"LotNumber"			: random.randint(1, 100),
		"Site"				: site,
		"Fixture"			: random.randint(1, 100),
		"SKU"				: random.randint(1, 100),
		"PairingDistance"	: random.uniform(1, 100),
		"Year"				: system.date.getYear(hoy),
		"Month"				: system.date.getMonth(hoy),
		"Day"				: system.date.getDayOfMonth(hoy),
		"Hour"				: system.date.getHour24(hoy),
		"Minute"			: system.date.getMinute(hoy),
	}
	return Results

def createEx():
	Datalog = [returnRandomResult() for i in range(200)]
	tag.write(Buff_Prev, Datalog)
	
	for MainSQ_ForCount in range(199, 0, -1): #Indices del 199 al 1
		
		#El valor n-1 se copia al n. Ej; Así Datalog[198]->Así Datalog[199]
		Datalog[MainSQ_ForCount] = Datalog[MainSQ_ForCount-1] 
	
	Datalog[0] = returnRandomResult()
	tag.write(Buff_Current, Datalog)