def sumar1Dia(date):
	date = system.date.addDays(date, 1)
	date = system.date.addSeconds(date, -1)
	return date

#DECORADOR PARA GENERAR COMO FECHA DEFAULT LA FECHA ACTUAL:
def nowDefault(func):
	
	def wrap(now=None):
		if not now:
			now=system.date.now()
		return  func(now)
		
	return wrap

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#FUNCIÓN PARA OBTENER EL AÑO, MES Y DÍA DE UNA FECHA DADA
#	INPUTS:
#		-now: fecha de la semana actual
#	OUTPUTS:
#		-year: Año actual
#		-month: Mes actual
#		-day: día actual
@nowDefault
def anioMesDia(now):
	year 	= system.date.getYear(now) 			# Año actual
	month 	= system.date.getMonth(now) 		# Mes actual
	day 	= system.date.getDayOfMonth(now)	# Día del mes actual
	
	return year, month, day

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#FUNCIÓN PARA OBTENER EL PRIMER Y ULTIMO DÍA DEL AÑO PASADO:
#	INPUTS:
#		-now: fecha de la semana actual
#	OUTPUTS:
#		-1ero de enero
#		-31 de diciembre
@nowDefault
def ultimoAnio(now):
	year, month, day = anioMesDia(now)
	
	#1ero enero año pasado
	primeroEnero = system.date.getDate(year-1, 0, 1)
	
	#31 de diciembre:
	ultimoDiaDic = system.date.getDate(year-1, 11, 31)
	
	return primeroEnero, ultimoDiaDic
	
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#FUNCIÓN PARA OBTENER EL DIA N, Y EL DIA N-1:
#	INPUTS:
#		-now: fecha de la semana actual
#	OUTPUTS:
#		-hoy
#		-ayer
@nowDefault
def ayerYhoy(now):
	year, month, day = anioMesDia(now)
	
	#Fecha actual desde las 00:00 horas
	now_mn = system.date.getDate(year, month, day)
	
	return system.date.addDays(now_mn, -1), now_mn
	
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#FUNCIÓN PARA OBTENER EL PRIMER Y ÚLTIMO DÍA DE LA SEMANA PASADA:
#	INPUTS:
#		-now: fecha de la semana actual
#	OUTPUTS:
#		-primerDiaDeLaSemanaAnterior (LUNES DE LA SEMANA PASADA A LAS 12 MN)
#		-ultimoDiaDeLaSemanaAnterior (LUNES DE ESTA SEMANA PASADA A LAS 12 MN)
@nowDefault
def primerYUltimoDiaDeLaSemanaPasada(now):	
	year, month, day = anioMesDia(now)
	
	#Fecha actual desde las 00:00 horas
	now_mn = system.date.getDate(year, month, day)
	
	#Día de la semana en el que estamos (lunes es el día 0)
	weekDay = system.date.getDayOfWeek(now)
	weekDay = 6 if (weekDay == 1) else  weekDay-2
	
	
	primerDiaDeLaSemanaAnterior=system.date.addDays(now_mn, -(weekDay+7))
	ultimoDiaDeLaSemanaAnterior=system.date.addDays(now_mn, -(weekDay))
	return primerDiaDeLaSemanaAnterior, ultimoDiaDeLaSemanaAnterior
	
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
#FUNCIÓN PARA OBTENER EL PRIMER Y ÚLTIMO DÍA DEL MES PASADO:
#	INPUTS:
#		-now: fecha de la semana actual
#	OUTPUTS:
#		-primerDiaDelMesPasado (1er día del mes pasado)
#		-ultimoDiaDelMesPasado (último día del mes pasado)
@nowDefault
def primerYUltimoDiaDelMesPasado(now):	
	year, month, day = funcionesDeFechas.anioMesDia(now)
	
	#Fecha actual desde las 00:00 horas
	now_mn = system.date.getDate(year, month, day)
	
	ultimoDiaDelMesAnterior = system.date.addDays(now_mn, -day)
	anio, mes, _=funcionesDeFechas.anioMesDia(ultimoDiaDelMesAnterior)
	primerDiaDelMesAnterior	= system.date.getDate(anio, mes, 1)
	
	return primerDiaDelMesAnterior, ultimoDiaDelMesAnterior

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
#DECORADOR PARA INDICAR EL TIPO DE METODO PARA OBTENER LAS FECHAS:
def modoFechas(func):
	def wrap(path, tipoFecha="", startDate=None, endDate=None):
		if tipoFecha =="M": 	#Tiempo encendido en un mes
			startDate, endDate = primerYUltimoDiaDelMesPasado()
		if tipoFecha =="ME": 	#Tiempo encendido en un mes (hasta fin de mes ; 11:59)
			startDate, endDate = primerYUltimoDiaDelMesPasado()
			endDate = sumar1Dia(endDate)
			
		elif tipoFecha =="W":	#Tiempo encendido en una semana
			startDate, endDate = primerYUltimoDiaDeLaSemanaPasada()
		elif not(startDate) and not(endDate):
			return 0	
		
		print(startDate)
		print(endDate)
		return  func(path, startDate, endDate)
	return wrap

#FUNCIÓN PARA OBTENER LAS HORAS DE ENCENDIDO DE UNA AHU DADAS CIERTAS FECHAS:
#	INPUTS:
#		-path: Ruta del AHU
#		-tipoFecha: Dictar si me intersan los datos de último mes o la última semana
#		-startDate: Fecha de inicio (no se proporciona tipoFecha)
#		-endDate: Fecha de fin (no se proporciona tipoFecha)
#
#	OUTPUTS:
#		-horasEncendido 		
@modoFechas
def horasEncendidoAHU(path, startDate, endDate):
	limEncendido = float(system.tag.read("[HologicTagProvider]Hologic/CR/AHUs/threshold").value) #IMPORTANTE: Se definio como minimo
	registros=dataStructs.tagQuery(path, startDate, endDate)
	
	if len(registros)==0:
		return 0
		
	minutos=0
	
	for reg in registros:
		fechDelRegistro		= reg[0]
		valorDelRegistro	= float(reg[1])
		
		if valorDelRegistro>= limEncendido:
			
			minutos+=15
		
	horas = minutos/60.0
	horas = round(horas)
	return horas
	
#FUNCIÓN PARA OBTENER EL VALOR DE UN MEDIDOR EN UN INTERVALO DDO DE TIEMPO
#	INPUTS:
#		-path: Ruta del Medidor
#		-startDate: Fecha de inicio (no se proporciona tipoFecha)
#		-endDate: Fecha de fin (no se proporciona tipoFecha)
#
#	OUTPUTS:
#		-diferencia: Energía consumida en el intervalo 
""" VERSION #1
def medidorEnRangoDeFechas(path, fechaInicial, fechaFinal, returnAll=False):
	#return 2
	calc  = ["Maximum","Minimum"]
	DS=system.tag.queryTagCalculations(paths=[path], startDate=fechaInicial, endDate=fechaFinal,  calculations=calc)

	py_DS=system.dataset.toPyDataSet(DS)
	try:
		maximo=py_DS[0][1]
		minimo=py_DS[0][2]
	except:
		print("STD: ", fechaInicial, "END: ",fechaFinal)
		print (list(py_DS))
		return 0
		
	diferencia=maximo-minimo
	if returnAll:
		return diferencia, maximo, minimo	
	return diferencia
"""

""" VERSION #2"""
def medidorEnRangoDeFechas(path, fechaInicial, fechaFinal, returnAll=False):
	paths=[path]
	calculations=["LastValue"]
	mayor=system.tag.queryTagCalculations(paths, calculations, fechaInicial, fechaFinal)
	mayor=float(system.dataset.toPyDataSet(mayor)[0][1])
	
	
	fechaInicial_0 = system.date.addSeconds(fechaInicial, -1)
	menor=system.tag.queryTagCalculations(paths, calculations, fechaInicial_0, fechaInicial)
	menor=float(system.dataset.toPyDataSet(menor)[0][1])
	delta=mayor-menor
	
	if returnAll:
		return delta, mayor, menor
		
	return delta
	
#FUNCIÓN PARA OBTENER EL VALOR DE UN MEDIDOR EN UN INTERVALO DDO DE TIEMPO
#	INPUTS:
#		-path: Ruta del Medidor
#		-startDate: Fecha de inicio (no se proporciona tipoFecha)
#		-endDate: Fecha de fin (no se proporciona tipoFecha)
#
#	OUTPUTS:
#		-diferencia: Energía consumida en el intervalo 
def ultimoValorDelRegistro(path, fechaInicial, fechaFinal):
	ds=system.tag.queryTagCalculations(paths=[path], startDate=fechaInicial, endDate=fechaFinal,  calculations=["LastValue"])
	pyDs=system.dataset.toPyDataSet(ds)
	return pyDs[0][1]
	
