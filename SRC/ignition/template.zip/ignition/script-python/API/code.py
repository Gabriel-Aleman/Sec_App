import json

def Put_request(jsonData): #jsonData debe ser una lista

	mi_url = "http://127.0.0.1:8000/items"
	jsonData = list(jsonData)
	jsonData = [dict(i) for i in jsonData]
	
	# Convertir dict a JSON 
	stringjsonString = system.util.jsonEncode(jsonData)
	
	# Enviar PUT con JSON
	
	response = system.net.httpPut(mi_url, "application/json",   stringjsonString)
	print response
	
def Put_request_Limits(tag_max = "[HologicTagProvider_Brev]Hologic/CR/Lim_Upper_PairDist", tag_min = "[HologicTagProvider_Brev]Hologic/CR/Lim_Lower_PairDist"): #jsonData debe ser una lista

	mi_url = "http://127.0.0.1:8000/limites"
	mininimo	=  tag.read(tag_min)
	maximo	 	=  tag.read(tag_max)
	
	jsonData = {"min":mininimo,"max":maximo}
	
	# Convertir dict a JSON 
	stringjsonString = system.util.jsonEncode(jsonData)
	
	# Enviar PUT con JSON
	
	response = system.net.httpPut(mi_url, "application/json",   stringjsonString)
	print response

def actualizar_Api():
	try:
		jsonData = tag.read("[HologicTagProvider_Brev]Hologic/CR/Reporte/Reporte")
		API.Put_request_Limits()
		API.Put_request(jsonData)
	except:
		pass
		
#Hash
"""

import hashlib


# Contraseña original
start 	= system.date.now()
i		= 0

password = "999999"
pin_enc = hashlib.sha256(password.encode()).hexdigest()

while True:
	# Crear hash con SHA-256
	password = str(i)
	hashed_password = hashlib.sha256(password.encode()).hexdigest()

	if hashed_password == pin_enc:
		break	
	i+=1

end 	= system.date.now()
i
system.date.minutesBetween(start, end)
"""