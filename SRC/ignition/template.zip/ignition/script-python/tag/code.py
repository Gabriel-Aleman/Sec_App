def read(path=""): 
	try: 
		val=system.tag.read(path).value 
	except: 
		system.gui.warningBox("No se puso leer el tag") 
	else: 
		return val
		
def write(path="", value=""): 
	try: 
		system.tag.write(path, value) 
	except: 
		system.gui.warningBox("No se puso escribir el tag")