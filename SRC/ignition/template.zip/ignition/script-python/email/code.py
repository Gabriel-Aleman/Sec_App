"""
	system.file.writeFile("C:\Bitacora\BitacoraNew.html", HTML)
	
	smtp 	= "smtp.hologic.com"
	sender = "bms@hologic.com"
	subject = "Bitacora "+ filename
	body = "Envio de Bitacora archivo HTML Adjunto: " + filename	
	EmailList=system.tag.read("[HologicTagProvider]Hologic/CR/BITACORA/EmailList").value
	recipients = EmailList
	system.net.sendEmail(smtp, sender, subject, body, 0, recipients, [filename], [HTML])
"""**