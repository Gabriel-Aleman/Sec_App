def listaDeRoles(sesId, secDocPath="[edge]IREX/TresRios_Cartago/SecurityDoc"):
	try:
		roles=tag.read(secDocPath)[sesId]
	except:
		return []
	else:
		return list(roles["rol"])