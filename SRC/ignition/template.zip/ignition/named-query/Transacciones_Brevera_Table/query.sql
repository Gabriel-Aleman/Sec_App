SELECT * FROM Transacciones_Brevera
WHERE ("t_stamp" >= :start AND "t_stamp" <= :end);